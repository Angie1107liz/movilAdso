//se debe cambiar la poscion de importacion y solocarlos en la parte de abajo.
//por que se hace de manera secuencial.

//ASCII ->Es un sistema de codificacion numerico unico a diferente caracteres 

//nos encargamos en el js de la entidad que vamos a utilziar

document.getElementById("titulo").addEventListener("Keypress",soloLetras);
document.getElementById("autor").addEventListener("Keypress",soloLetras);
document.getElementById("ISBN").addEventListener("Keypress",soloLetras);
document.getElementById("genero").addEventListener("Keypress",soloLetras);





   //Primer manera:

/**
   const letrasPermitidas =[
    'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w',
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W',
    'á','é','í','ó','ú','Á','É','Í','Ó','Ú','ñ', 'Ñ' , ''
   ];
   const numerosPermitidos =[
   '1','2','3','4','5','6','7','8','9','0'
   ];
   const signosPermitidos[
   
   '.',',','@'
   ]
   se pone en la funcion

      if(!(letrasPermitidas,includes(event.Key))){
    event.preventDefault();
    return;
   }

 */

const noPermitidas=[
    '/','<','>','',"",'{','}','[',']','(',')'
]
 
function soloLetras(event){
    console.log("Llave presionada: " +event.Key);
    console.log("codigo tecla: " +event.KeyCode);// estas lineas estan diseñadas para para mostrar informacion sobre la letra que coloco el usuario 

    //se debe ajustar para aceptar minusculas, mayusculas, letras con tilde y espacio

    //segunda manera de hacer:

    if(!(event.KeyCode>=65 && event.KeyCode<=90|| event.KeyCode>=97 && event.KeyCode<=122 || event.KeyCode == 32 ||event.KeyCode ==130||event.KeyCode>=160 && event.KeyCode<=163||event.KeyCode>=164 && event.KeyCode>=165)){ 
        event.preventDefault();
        return;
   }

if (!(noPermitidas,includes(event.Key))){
    event.preventDefault();
    return;
}
}



